"""FitBuddy application package."""
